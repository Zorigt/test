//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255HJ
//MP3ManagerTest
//tests MP3Manager
//Assignment #8
//5-13-14

import javax.swing.JFrame; 

public class MP3ManagerTest 
{	
	public static void main( String[]args )
	{
		//instantiate mp3 object of MP3Manager 
		MP3Manager mp3 = new MP3Manager(); 
		mp3.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		mp3.setSize( 500, 600 ); 
		mp3.setVisible( true ); 
	}
	
}
