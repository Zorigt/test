//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255HJ
//MP3Manager
//mp3 GUI
//Assignment #8
//5-13-14

import javax.swing.*;  
import java.awt.*; 
import java.awt.event.*; 
import java.io.IOException; 
import java.io.FileWriter;
import java.io.BufferedWriter; 
import java.util.ArrayList; 
import java.util.Collections;
import java.io.FileReader; 
import java.io.BufferedReader; 
import java.io.File;  

public class MP3Manager extends JFrame
{	
	private JPanel northPanel; 
	private JLabel artistLabel; 
	private JLabel songLabel; 
	private JLabel albumLabel;
	private JLabel trackLabel; 
	private JTextField artistField;
	private JTextField songField;
	private JTextField albumField;
	private JTextField trackField; 
	private JButton addButton;
	private JButton displayButton;
	private JButton findButton; 
	private JButton deleteButton;
	private JTextArea southArea; 
	//BufferedWriter instance for better performance
	private BufferedWriter out; 
	//array list temporarily stores MP3s
	ArrayList<MP3> mp3List = new ArrayList<MP3>();
	//BufferredReader instance 
	private BufferedReader readIn; 
	
	//no-argument constructor 
	public MP3Manager()
	{
		super( "MP3 Manager - Programmed by Jonathan Co" );
		
		//panel containing labels, fields and buttons 
		northPanel = new JPanel(); 
		northPanel.setLayout( new GridLayout( 7, 2 ) );
		//artist line
		artistLabel = new JLabel( "Artist Name", SwingConstants.RIGHT ); 
		northPanel.add( artistLabel ); 
		artistField = new JTextField();
		northPanel.add( artistField ); 
		//song line 
		songLabel = new JLabel( "Song Title", SwingConstants.RIGHT ); 
		northPanel.add( songLabel ); 
		songField = new JTextField(); 
		northPanel.add( songField ); 
		//album line 
		albumLabel = new JLabel( "Album Name", SwingConstants.RIGHT ); 
		northPanel.add( albumLabel ); 
		albumField = new JTextField(); 
		northPanel.add( albumField ); 
		//track line 
		trackLabel = new JLabel( "Track Length (in seconds)",
                                SwingConstants.RIGHT );
		northPanel.add( trackLabel ); 
		trackField = new JTextField(); 
		northPanel.add( trackField ); 
		//buttons 
		addButton = new JButton( "Add MP3" ); 
		displayButton = new JButton( "Display MP3" );  
		findButton = new JButton( "Find MP3" ); 
		deleteButton = new JButton( "Delete MP3" ); 
		northPanel.add( addButton ); 
		northPanel.add( displayButton );
		northPanel.add( findButton );
		northPanel.add( deleteButton ); 
		
		//create text area 
		southArea = new JTextArea(); 
		
		//create new ButtonHandler for button event handling
		ButtonHandler handler = new ButtonHandler(); 
		addButton.addActionListener( handler ); 
		displayButton.addActionListener( handler ); 
		findButton.addActionListener( handler ); 
		deleteButton.addActionListener( handler );
		
		setLayout( new BorderLayout() );
		add( northPanel, BorderLayout.NORTH ); 
		add( southArea, BorderLayout.CENTER ); 
	}
	
	//private inner class for button event handling
	private class ButtonHandler implements ActionListener
	{
		//handle button event 
		public void actionPerformed( ActionEvent event )
		{	 
			if( event.getSource() == addButton )
			{
				//make sure all fields are filled 
				if( artistField.getText().equals( "" ) || songField.getText()
						.equals( "" ) || albumField.getText().equals( "" ) ||
						trackField.getText().equals( "" ) )
						southArea.setText( "Input data missing - "
								+ "please fill in all fields" ); 
				else 
				{
					try 
					{	
						MP3 mp3 = new MP3( artistField.getText(),
                                      songField.getText(), albumField.getText(),
                                      Integer.parseInt( trackField.getText() ) );
				
						//display mp3 data 
						southArea.setText( mp3.toString() );
					
						//string stores MP3 data to be into file
						String inputData = String.format( "%s:%s:%s:%d\n", 
							artistField.getText(),songField.getText(), 
							albumField.getText(), 
							Integer.parseInt( trackField.getText() ) );
						//input data into MP3 file 
						appendToFile( inputData ); 
				
						//reset fields
						artistField.setText( "" ); 
						songField.setText( "" );
						albumField.setText( "" );
						trackField.setText( "" );
					//integer not fed into parseInt 
					} catch( NumberFormatException numberFormatMismatch ) {
						//string shown if exception thrown 
						southArea.setText( "must enter number for seconds" );
					}	
				
				}
			
			} else if( event.getSource() == displayButton )
			{	
					//call sort method 
					sortArrayList( toArrayList() ); 
					
					//clear text area before displaying MP3s
					southArea.setText( "" ); 
					
					for( MP3 currMP3 : mp3List )
						southArea.append( currMP3.toString() + "\n" );
					
					//clear array list 
					mp3List.clear(); 
					
			} else if( event.getSource() == findButton )
			{	
				//make sure user entered song name 
				if( songField.getText().equals( "" ) || artistField.getText()
					.length() > 0|| albumField.getText().length() > 0 || 
					trackField.getText().length() > 0)
					southArea.setText( "Please enter song name only to "
							+ "find record" );
				else {
					//trim song to be found 
					String findSong = songField.getText().trim(); 
					
					if( foundMP3( findSong ) != null )
						//display record if found 
						southArea.setText( foundMP3( findSong ).toString() ); 
					else
						southArea.setText( "No MP3 record found for " + 
								songField.getText() ); 
				}
					
			} else if( event.getSource() == deleteButton )
			{
				//make sure user entered song name 
				if( songField.getText().equals( "" ) || artistField.getText()
					.length() > 0 || albumField.getText().length() > 0 || 
					trackField.getText().length() > 0)
					southArea.setText( "Please enter song name only to "
							+ "delete record" );
				else {
					//trim song to be found 
					String findSong = songField.getText().trim(); 
					//read file into array list 
					toArrayList(); 
					
					if( foundMP3( findSong ) != null )
					{ 	
						//confirm delete 
						if( JOptionPane.showConfirmDialog( null, "Song found, "
								+ "confirm delete?", "Choose One", JOptionPane
								.YES_NO_OPTION ) == JOptionPane.YES_OPTION )
						{
							deleteMP3ArrayList( findSong ); 
							overwriteFile( mp3List ); 
						} else {
							southArea.setText( findSong + " not deleted" ); 
							//clear array list if user does not delete record 
							mp3List.clear(); 
						}
						
					} else {
						southArea.setText( "No MP3 record found to be deleted" ); 
						mp3List.clear(); 
					}	
				}
					
			}
			
		} //end actionPerformed
		
	} //end private inner class 
	
	
	//append to file 
	private void appendToFile( String data ) 
	{
		try {
			out = new BufferedWriter( new FileWriter( "MP3.txt", true ) ); 
			out.write( data ); 
			closeFile();  
		} catch( IOException exception ) {
			southArea.setText( "Error in adding MP3 to file: " + exception ); 
		}
		
	}
	
	//close file 
	private void closeFile()
	{
		if( out != null )
			try 
			{ 
				out.close();
			} catch( IOException ioe ) {
				southArea.setText( "Error closing file: " + ioe ); 
			} 
		
	}
	
	//open and read file 
	private void openFile()
	{
		try
		{
			File file = new File( "MP3.txt" ); 
			readIn = new BufferedReader( new FileReader( file ) ); 
		} catch( IOException ioe ) {
			southArea.setText( "Error opening file: " + ioe ); 
		} 
		
	}
	
	//sort file on artist name 
	private void sortArrayList( ArrayList<MP3> mp3s )
	{
		//loop through array list 
		for( int pass = 1; pass < mp3s.size(); pass++ )
		{
			for( int index = 0; index < mp3s.size() - 1; index++ )
			{
				//swap adjacent elements if compare to is greater than zero
				if( mp3s.get( index ).getArtist().compareToIgnoreCase( 
						mp3s.get( index + 1 ).getArtist() ) > 0 )
					//swap elements 
					Collections.swap( mp3s, index, index + 1); 
			}
			
		}
	}
	
	//create array list 
	private ArrayList<MP3> toArrayList() 
	{	
		openFile(); 
		try 
		{
			String currentLine; 
			while( ( currentLine = readIn.readLine() ) != null )
			{
				String[] splitInput = currentLine.split( ":" ); 
				//create new MP3 object
				MP3 tempMp3 = new MP3( splitInput[ 0 ], splitInput[ 1 ], 
						splitInput[ 2 ], Integer.parseInt( splitInput[ 3 ] ) );  
				//add MP3 object to array list 
				mp3List.add( tempMp3 );
			}
			
		} catch (IOException ioe) {					
			southArea.setText( "Error reading file: " + ioe ); 
		} finally {
			closeFile(); 
		}
		
		return mp3List; 
	}
	
	//find mp3
	private MP3 foundMP3( String find )
	{
		//returns null if not found 
		MP3 foundMP3 = null; 
		
		openFile(); 
		try
		{
			String currentLine; 
			while( ( currentLine = readIn.readLine() ) != null )
			{
				String[] splitInput = currentLine.split( ":" ); 
				if( find.equalsIgnoreCase( splitInput[ 1 ] ) )
					foundMP3 = new MP3( splitInput[ 0 ], splitInput[ 1 ],
						splitInput[ 2 ], Integer.parseInt( splitInput[ 3 ] ) ); 
			}
			
		} catch( IOException ioe ) {
			southArea.setText( "Error reading file: " + ioe );
		} finally {
			closeFile(); 
		}
	
		return foundMP3; 
	}
	
	//return array list without mp3 to be deleted 
	private ArrayList<MP3> deleteMP3ArrayList( String toBeDeleted ) 
	{
		//clear array list 
		mp3List.clear(); 
		//initialize temporary MP3 object 
		MP3 tempMp3 = null; 
		
		openFile();
		try 
		{
			String currLine; 
			while( ( currLine = readIn.readLine() ) != null )
			{
				String[] splitLine = currLine.split( ":" );
				if( !toBeDeleted.equalsIgnoreCase( splitLine[ 1 ] ) )
				{	
					//create new MP3 object
					tempMp3 = new MP3( splitLine[ 0 ], splitLine[ 1 ], 
						splitLine[ 2 ], Integer.parseInt( splitLine[ 3 ] ) );  
					//add MP3 object to array list 
					mp3List.add( tempMp3 );
				}
				
			}
			
		} catch (IOException ioe) {					
			southArea.setText( "Error reading file: " + ioe ); 
		} finally {
			closeFile(); 
		}
			
		return mp3List; 
	}
	
	//overwrite file 
	private void overwriteFile( ArrayList<MP3> mp3s )
	{
		try 
		{	
			//open file and start output stream at beginning 
			out = new BufferedWriter( new FileWriter( "MP3.txt" ) ); 
			
			//write all output stream 
			for( MP3 current : mp3s )
			{
				String outputToFile = String.format( "%s:%s:%s:%d\n", 
					current.getArtist(), current.getSong(), 
					current.getAlbum(), current.getTrackLength() );   
				out.write( outputToFile );
			}
			
			//close file 
			closeFile();
		} catch( IOException exception ) {
			southArea.setText( "Error in overwrite file: " + exception ); 
		} finally {
			closeFile();
		}
		
	}
	
}
