//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255HJ
//MP3
//mp3 data 
//Assignment #8
//5-13-14

/** 
 * MP3 Class stores MP3 data  
 * @author Jonathan Co 
 * @version 1.0 
 *
 */
public class MP3 
{
	private String artist; 
	private String song; 
	private String album; 
	private int trackLength; 
	
	/** 
	 * MP3 Constructor constructs an MP3 record with an  
	 * artist, song, album and track length
	 * @param artist	the artist name of MP3 record
	 * @param song		the song name of MP3 record
	 * @param album		the album name of MP3 record 
	 * @param tLength	the track length of MP3 record 
	 */
	public MP3( String artist, String song, String album, int tLength )
	{
		setArtist( artist );
		setSong( song ); 
		setAlbum( album );
		setTrackLength( tLength ); 
	}
	
	//accessors
	/**
	 * Gets the artist name
	 * @return a <code>String</code> specifying the artist
	 */
	public String getArtist()
	{
		return artist; 
	}
	
	/**
	 * Gets the song name 
	 * @return a <code>String</code> specifying the song 
	 */
	public String getSong()
	{
		return song; 
	}
	
	/**
	 * Gets the album name
	 * @return a <code>String</code> specifying the album 
	 */
	public String getAlbum()
	{
		return album;
	}

	/**
	 * Gets the track length
	 * @return a <code>int</code> specifying the track length
	 */
	public int getTrackLength()
	{
		return trackLength; 
	}
	
	//mutators
	/**
	 * Sets the artist 
	 * @param artist the artist name
	 */
	public void setArtist( String artist )
	{
		this.artist = artist;
	}
	
	/**
	 * Sets the song
	 * @param song the song name
	 */
	public void setSong( String song )
	{
		this.song = song; 
	}
	
	/**
	 * Sets the album
	 * @param album the album name
	 */
	public void setAlbum( String album )
	{
		this.album = album; 
	}
	
	/**
	 * Sets the track length
	 * @param tLength the track length in seconds 
	 */
	public void setTrackLength( int tLength )
	{
		trackLength = tLength <= 0 ? 1 : tLength;  
	}
	
	//toString converts track length into minutes and seconds 
	/**
	 * Convert to String with | as delimeters 
	 * and MM:SS track length 
	 * @return a <code>String</code> representation 
	 * of MP3 record 
	 */
	public String toString()
	{
		int minutes, seconds; 
		
		minutes = getTrackLength() / 60; 
		seconds = getTrackLength() - ( minutes * 60 );
		
		return String.format( "%s | %s | %s | %d:%02d", getArtist(), getSong(), 
			getAlbum(), minutes, seconds ); 			
	}
	
}
