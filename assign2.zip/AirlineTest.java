//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255 HJ 
//AirlineTest.java
//tests Airline class 
//Assignment #2
//2-11-14

import java.util.Scanner; 

public class AirlineTest 
{
	public static void main( String[]args ) 
	{
		Scanner input = new Scanner( System.in ); 
		//create airline object 
		Airline airline = new Airline(); 
		
		int userChoice = 0; 
		
		System.out.print( "Programmed by Jonathan Co\n\n"
				+ "Welcome to Java Airways" );
		do
		{
			//prompt 
			System.out.printf( "\n%s\n%s\n%s",
				"Please type \'1\' for First Class",
				"Please type \'2\' for Economy", 
				"choice: " );
			userChoice = input.nextInt(); 
			//call appropriate methods 
			switch( userChoice )
			{
				case 1: 
					airline.firstClass();
					break;
				case 2: 
					airline.economyClass();
					break;
				default:
					break; 
			}
			
			//condition ends loop when plane full and controls input 
		} while( airline.seatCount < 10 && 
			( userChoice != 1 || userChoice != 2 ) );
		
		//full plane output 
		System.out.printf( "\n%s\n%s",
				"Plane is full", 
				"Next flight leaves in 3 hours." );
	} //end main method 

} //end class AirplaneTest
