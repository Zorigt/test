//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255 HJ 
//Airline.java
//assigns seats in 10 seat airplane 
//Assignment #2
//2-11-14

import java.util.Scanner; 

public class Airline 
{
	//full flight constant 
	private final int FULL_FLIGHT = 10;
	//boolean array 
	private boolean[] seats; //declare seats array 
	private int firstCount = 0; //first class seat counter 
	private int economyCount = 5; //economy class seat counter 
	int seatCount = 0; //overall seat count 
	
	Scanner input = new Scanner( System.in ); 
	
	public Airline()
	{
		//initialize array size
		seats = new boolean[ FULL_FLIGHT ]; 
		//initialize array values to false 
		for( int i = 0; i < seats.length; i++ )
			seats[ i ] = false; 
	}
	
	public void firstClass()
	{
		//validation
		if( fullPlane() )
			return; 
		//condition to check first class available 
		if( firstCount < 5 )
		{
			//assign seats
			seats[ firstCount++  ] = true; 
			System.out.printf( "%s\n%s%d\n%s\n",
				"************************************",
				"\tFirst Class Seat #",
				firstCount,
				"************************************" );
			seatCount++; 
		} else
			//first class is full, ask about economy 
			fullFirst(); 
	} 
	
	public void economyClass()
	{
		//validation 
		if( fullPlane() )
			return; 
		//condition to check economy available 
		if( economyCount >= FULL_FLIGHT / 2 && economyCount < FULL_FLIGHT )
		{
			//assign seats 
			seats[ economyCount++ ] = true; 
			System.out.printf( "%s\n%s%d\n%s\n",
				"************************************",
				"\tEconomy Class Seat #",
				economyCount, 
				"************************************" ); 
			seatCount++; 
		} else 
			//economy class is full, ask about first 
			fullEconomy(); 	
	}
	
	//method asks if user wants economy class when first is full 
	public void fullFirst()
	{
		int userChoice; 
		do
		{
			//prompt 
			System.out.printf( "\n%s\n%s", 
				"First class is full, Economy class?", 
				"1 - Yes , 2 - No  Your Choice: " );
			userChoice = input.nextInt(); 
			switch( userChoice )
			{
				case 1: 
					//call economy class method because user does not 
					//mind that first class is full 
					economyClass(); 
					break;
				case 2:
					System.out.print( "Next flight leaves in 3 hours." );
					userChoice = -1; 
					break;
				default: 
					break; 
			}
				
		//condition makes sure plane is NOT full and userChoice is appropriate
		} while( !fullPlane() && ( userChoice == 1 || userChoice == 2 ) ); 
		
	}
	
	//method asks if user wants first class when economy is full 
	public void fullEconomy()
	{
		int userChoice; 
		do
		{
			//prompt
			System.out.printf( "\n%s\n%s", 
				"Economy class is full, First class?", 
				"1 - Yes , 2 - No  Your Choice: " );
			userChoice = input.nextInt(); 
			switch( userChoice )
			{
				case 1: 
					//call first class method because user does not 
					//mind that economy class is full 
					firstClass(); 
					break;
				case 2: 
					System.out.print( "Next flight leaves in 3 hours." );
					userChoice = -1; 
					break;
				default: 
					break; 
			}
		
		//condition makes sure plane is NOT full and userChoice is appropriate
		} while( !fullPlane() && ( userChoice == 1 || userChoice == 2 ) ); 
			
	}
	
	//method checks if plane is full
	public boolean fullPlane() 
	{
		boolean full; 
		//plane is not full return false
		if( seatCount < 10 )
			full = false; 
		//plane full returns true 
		else 
			full = true;
		
		return full; 
	}
	
} //end Airplane class
