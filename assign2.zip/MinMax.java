//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255 HJ 
//MinMax.java
//recursive methods find min and max
//Assignment #2
//2-11-14

public class MinMax 
{
	//recursive method finds minimum number in array 
	public static int recursiveMinimum( int[] array, int index )
	{
		//test until last valid index
		if( index == array.length - 1 ) 
			//if smallest number comes first in array 
			return array[ index ]; 
		else
			//math class method finds minimum, increment index
			return Math.min( array[ index ],  
				recursiveMinimum( array, index + 1 ) ); 
	} //end recursive method recursiveMinimum 
	
	//recursive method finds maximum number in array 
	public static int recursiveMaximum( int[] array, int index )
	{
		//test until last valid index
		if( index == array.length - 1 )   
			//if largest number comes first in array 
			return array[ index ]; 
		else
			//math class method finds maximum, increment index 
			return Math.max( array[ index ],  
				recursiveMaximum( array, index + 1 ) ); 
	} //end recursive method recursiveMaximum
}
