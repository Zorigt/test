//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255 HJ 
//MinMaxTest.java
//tests MinMax class
//Assignment #2
//2-11-14

import javax.swing.JOptionPane; 

public class MinMaxTest 
{
	public static void main( String[]args )
	{
		//string output 
		String message = String.format( "Programmed by Jonathan Co\n\n" ); 
		//initialize array with 9 integer values 
		int[] array = { 22, 88, 8, 94, 78, 84, 96, 73, 34 }; 
		
		//format array output
		message += "Array:\n"; 
		for( int value : array )
			message += " " + value; 
		
		//format largest and smallest outputs 
		//call recursive methods 
		message += "\n\nThe smallest value in the array is: " 
			+ MinMax.recursiveMinimum( array, 0 ) + 
			"\nThe largest value in the array is: " +
			MinMax.recursiveMaximum( array, 0 ); 
		
		JOptionPane.showMessageDialog( null, message );
	}
}
