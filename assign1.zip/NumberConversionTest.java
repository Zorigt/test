//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255 HJ 
//NumberConversionTest.java
//displays table with numbers 1 - 256 in decimal, octal 
//and hexadecimal format 
//Assignment #1
//1-21-14

public class NumberConversionTest 
{
	public static void main( String[]args )
	{
		//counts 1-256
		int counter = 0; 
		//output header 
		System.out.printf( "%s\n%s\n", "Programmed by Jonathan Co",
			"Decimal   Binary    Octal     Hexadecimal" );
		//output loop increments counter 
		//calls static methods from NumberConversion Class 
		while( counter++ != 256 )
		{
			System.out.printf( "%-10d%-10s%-10s%-10s\n", counter,
				NumberConversion.convertToBinary( counter ),
				NumberConversion.convertToOctal( counter ),
				NumberConversion.convertToHexadecimal( counter ) );
		}
		
	} //end method main 

} //end class NumberConversionTest
