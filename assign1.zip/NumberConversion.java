//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255 HJ 
//NumberConversion.java
//three static methods convert decimal numbers to binary, 
//octal and hexadecimal numbers 
//Assignment #1
//1-21-14

public class NumberConversion 
{
	public static String convertToBinary( int number ) 
	{
		//empty string to be appended with output 
		String binaryResult = "";
		//validation
		if( number == 0 )
			binaryResult = "0"; 
		//binary conversion from decimal 
		while( number > 0 )
		{
			binaryResult = ( number % 2 ) + binaryResult;  
			number /= 2; 
		}
		
		return binaryResult; 
	} //end method convertToBinary 
	
	public static String convertToOctal( int number )
	{
		//empty string to be appended with output 
		String octalResult = ""; 
		//validation
		if( number == 0 )
			octalResult = "0"; 
		//octal conversion from decimal 
		while( number > 0 )
		{
			octalResult = ( number % 8 ) + octalResult;
			number /= 8; 
		}
		
		return octalResult; 
	} //end method convertToOctal 
	
	public static String convertToHexadecimal( int number )
	{
		//empty string to be appended with output 
		String hexResult = ""; 
		int remainder = 0; 
		//validation
		if( number == 0 )
			hexResult = "0"; 
		//hexadecimal conversion from decimal 
		while( number > 0 )
		{
			remainder = number % 16; 
			switch( remainder )
			{
				case 10: 
					hexResult += "A";
					break;
				case 11: 
					hexResult += "B"; 
					break; 
				case 12: 
					hexResult += "C"; 
					break; 
				case 13: 
					hexResult += "D";
					break; 
				case 14: 
					hexResult += "E";
					break;
				case 15: 
					hexResult += "F"; 
					break;
				default: 
					hexResult += remainder; 
					break; 
			}
			
			number = number / 16; 
		}
		
		return hexResult; 
	} //end method convertToHexadecimal 
	
} //end class NumberConversion 
