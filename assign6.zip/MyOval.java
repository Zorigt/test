//Jonthan Co 
//jco5@my.smccd.edu	
//CIS 255HJ
//MyOval
//oval subclass
//Assignment #6
//4-15-14

import java.awt.*;

public class MyOval extends MyBoundedShape
{
   //no argument constructor 
   public MyOval()
   {
	   super();  
   }
   
   // constructor with input values
   public MyOval( int x1, int y1, int x2, int y2, Color color, boolean fill )
   {
      super( x1, y1, x2, y2, color, fill ); 
   } 
    
   // Actually draws the shape
   //override abstract method draw inherited from MyShape
   @Override 
   public void draw( Graphics g )
   {
      g.setColor( getColor() );

      //condition if filled is true 
      if( isFilled() )
    	  g.fillOval( getUpperLeftX(), getUpperLeftY(), getWidth(), getHeight() );
      else
          g.drawOval( getUpperLeftX(), getUpperLeftY(), getWidth(), getHeight() );
   } // end method draw
   
} // end class MyLine