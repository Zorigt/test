//Jonthan Co 
//jco5@my.smccd.edu	
//CIS 255HJ
//MyBoundedShape
//my bounded shape subclass
//Assignment #6
//4-15-14

import java.awt.*; 

public abstract class MyBoundedShape extends MyShape
{
	private boolean filled; //shape filled or not 
	
	//no argument constructor 
	public MyBoundedShape()
	{
		//assign defaults 
		super( 0, 0, 0, 0, Color.BLACK );  
		filled = false; 
	}
	   
	// constructor with input values
	public MyBoundedShape( int x1, int y1, int x2, int y2, Color color, boolean fill )
	{
		super( x1, y1, x2, y2, color ); 
		setFilled( fill ); //set fill argument 
	} 

	//accessor 
    public boolean isFilled()
    {
    	return filled; 
    }
	
    //mutator 
    public void setFilled( boolean fill )
    {
    	filled = fill; 
    }
    
    //get upper left x coordinate
    public int getUpperLeftX()
    {
    	return Math.min( getX1(), getX2() ); 
    }
    
    //get upper left y coordinate 
    public int getUpperLeftY()
    {
    	return Math.min( getY1(), getY2() ); 
    }
    
    //width of bounded shape  
    public int getWidth()
    {
    	return Math.abs( getX1() - getX2() ); 
    }
    
    //height of bounded shape
    public int getHeight()
    {
    	return Math.abs( getY1() - getY2() ); 
    }
    
	//abstract draw() inherited
    //no need to override 
}
