//Jonthan Co 
//jco5@my.smccd.edu	
//CIS 255HJ
//ScreenSaver
//test screensaver
//Assignment #6
//4-15-14

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JFrame; 

public class ScreenSaver 
{
	public static void main( String[]args )
	{
		DrawPanel panel = new DrawPanel(); 
		JFrame application = new JFrame();
		
		application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		application.add( panel ); 
		
		//display without a title bar 
		application.setUndecorated( true );
		
		//fill the entire screen 
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); 
		int width = screenSize.width;
		int height = screenSize.height; 
		
		//set size of application window 
		application.setSize( width, height );
		
		//set background color in  main also 
		application.setBackground( Color.BLACK );
		
		application.setVisible( true ); 
	}
	
}
