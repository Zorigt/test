//Jonthan Co 
//jco5@my.smccd.edu	
//CIS 255HJ
//DrawPanel
//draws shapes onto Jpanel
//Assignment #6
//4-15-14

import java.awt.Graphics;
import java.awt.Color; 
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener; 
import java.util.Random;
import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D; 
import java.awt.GradientPaint; 
import java.awt.Paint; 
import java.awt.Toolkit;

public class DrawPanel extends JPanel 
{
   private Random randomNumbers = new Random(); 
   
   //account for mouseMoved being triggered even if mouse isn't moved  
   private boolean firstTime = true;
   //count shapes 
   private int shapeCount; 
   
   // constructor, creates a panel with random shapes
   public DrawPanel()
   {
      setBackground( Color.BLACK );
      
      //create and register listener for mouse motion events 
      MouseHandler handler = new MouseHandler(); 
      addMouseMotionListener( handler ); 
   } 

   //draw the individual shapes
   public void paintComponent( Graphics g )
   {
	   //call super.paintComponent if number of shapes is 100 
	   //clear previous 100 shapes to start drawing next 100 new random shapes 
	   if( shapeCount == 100 || shapeCount == 0 )
	   {
		   super.paintComponent( g );
	   }
      
	   //increase the count of shapes 
	   shapeCount++; 
	   
	   //fill the entire screen 
	   Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); 
	   int width = screenSize.width;
	   int height = screenSize.height; 
	  
	   // generate random coordinates
	   int x1 = randomNumbers.nextInt( width - 200 );
       int y1 = randomNumbers.nextInt( height - 200 );
       int x2 = x1 + 150; 
	   int y2 = y1 + 150;
	   
	   // generate two random colors
	   Color color = new Color( randomNumbers.nextInt( 256 ), 
			   randomNumbers.nextInt( 256 ), randomNumbers.nextInt( 256 ) );
	   Color color1 = new Color( randomNumbers.nextInt( 256 ), 
			   randomNumbers.nextInt( 256 ), randomNumbers.nextInt( 256 ) ); 
	   
	   //generate filled parameter
	   boolean fill = true;
	   
	   //generate random number to draw shape
	   int shapeNumber = randomNumbers.nextInt( 3 );
	   
	   Graphics2D g2 = ( Graphics2D )g.create();  
	   
	   //gradient paint cyclic or acyclic
	   boolean gradient = randomNumbers.nextBoolean(); 
	   
	   //draw one shape at a time with gradients
	   switch( shapeNumber )
	   {
     		case 0: 
     			MyShape shape = new MyOval( x1, y1, x2, y2, null, fill );
     			Paint p = new GradientPaint( x1, y1, color, x1 + 100, y1 + 100, color1, gradient ); 
     			g2.setPaint( p );
     			shape.draw( g2 );
     		break; 
     		case 1: 
     			MyShape shape1 = new MyRectangle( x1, y1, x2, y2, null, fill );
     			Paint p1 = new GradientPaint( x1, y1, color, x1 + 100, y1 + 100, color1, gradient ); 
     			g2.setPaint( p1 );
     			shape1.draw( g2 );
     		break; 
     		default:
     			MyShape shape2 = new MyArc( x1, y1, x2, y2, null, fill, 0, 180 ); 
     			Paint p2 = new GradientPaint( x1, y1, color, x1 + 100, y1 + 100, color1, gradient ); 
     			g2.setPaint( p2 );
     			shape2.draw( g2 ); 
     		break;         
	   }
	   
	   //delay so each random shape appears separately 
	   try
	   {
		   Thread.sleep( 700 ); 
	   } catch( Exception e ) {}

	   //force paintComponent to execute again and draw next random shape 
	   repaint(); 	      
      
   } // end method paintComponent
   
   private class MouseHandler implements MouseMotionListener
   {
	   @Override
	   //mouseDragged has empty implementation 
	   public void mouseDragged( MouseEvent event ){}

	   @Override
	   public void mouseMoved( MouseEvent event ) 
	   {
		   //condition checks as soon as screensaver launched, mouseMoved isn't triggered 
		   if( firstTime == false )
		   {
			   //screensaver application will shut down 
			   System.exit( 0 );
		   }
	   
		   //subsequent call to mouseMoved is result of mouse being moved 
		   firstTime = false; 
	   }	
	   
   }
   
} // end class DrawPanel