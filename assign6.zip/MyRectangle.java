//Jonthan Co 
//jco5@my.smccd.edu	
//CIS 255HJ
//MyRectangle
//rectangle subclass
//Assignment #6
//4-15-14

import java.awt.*; 

public class MyRectangle extends MyBoundedShape
{
   //no argument constructor 
   public MyRectangle()
   {
	   super(); 
   }
   
   // constructor with input values
   public MyRectangle( int x1, int y1, int x2, int y2, Color color, boolean fill )
   {
      super( x1, y1, x2, y2, color, fill ); 
   } 
    
   // Actually draws the line
  //override abstract method draw inherited from MyShape
   @Override 
   public void draw( Graphics g )
   {
      g.setColor( getColor() );

      //condition if filled is true 
      if( isFilled() )
    	  g.fillRect( getUpperLeftX(), getUpperLeftY(), getWidth(), getHeight() );
      else
          g.fillRect( getUpperLeftX(), getUpperLeftY(), getWidth(), getHeight() );
   } // end method draw
   
} // end class MyLine