//Jonthan Co 
//jco5@my.smccd.edu	
//CIS 255HJ
//MyArc
//my arc subclass
//Assignment #6
//4-15-14

import java.awt.Color;
import java.awt.Graphics;

public class MyArc extends MyBoundedShape
{
	//instances for start and ends of arcs 
	private int startAngle, endAngle; 
	
	//no argument constructor 
	public MyArc()
	{
		super();  
		startAngle = 0; 
		endAngle = 0; 
	}
	   
	// constructor with input values
	public MyArc( int x1, int y1, int x2, int y2, Color color, boolean fill, int sAngle, int eAngle )
	{
		super( x1, y1, x2, y2, color, fill ); 
		setStartAngle( sAngle );
		setEndAngle( eAngle ); 
	}
	
	public void setStartAngle( int sAngle )
	{
		startAngle = sAngle; 
	}
	
	public int getStartAngle()
	{
		return startAngle; 
	}
	
	public void setEndAngle( int eAngle )
	{
		endAngle = eAngle;
	}
	
	public int getEndAngle()
	{
		return endAngle; 
	}
	
	//override abstract method draw inherited from MyShape
	@Override
	public void draw( Graphics g ) 
	{
		g.setColor( getColor() );
		
		if( isFilled() )
			g.fillArc( getUpperLeftX(), getUpperLeftY(), getWidth(), getHeight(), getStartAngle(), getEndAngle() );
		else
			g.drawArc( getUpperLeftX(), getUpperLeftY(), getWidth(), getHeight(), getStartAngle(), getEndAngle() );
		
	}

}
