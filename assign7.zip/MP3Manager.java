//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255HJ
//MP3Manager
//mp3 GUI
//Assignment #7
//4-29-14

import javax.swing.*;  
import java.awt.*; 
import java.awt.event.*; 

public class MP3Manager extends JFrame
{	
	private JPanel northPanel; 
	private JLabel artistLabel; 
	private JLabel songLabel; 
	private JLabel albumLabel;
	private JLabel trackLabel; 
	private JTextField artistField;
	private JTextField songField;
	private JTextField albumField;
	private JTextField trackField; 
	private JButton addButton;
	private JButton displayButton;
	private JButton findButton; 
	private JButton deleteButton;
	private JTextArea southArea; 
	
	//no-argument constructor 
	public MP3Manager()
	{
		super( "MP3 Manager - Programmed by Jonathan Co" );
		
		//panel containing labels, fields and buttons 
		northPanel = new JPanel(); 
		northPanel.setLayout( new GridLayout( 7, 2 ) );
		//artist line
		artistLabel = new JLabel( "Artist Name", SwingConstants.RIGHT ); 
		northPanel.add( artistLabel ); 
		artistField = new JTextField();
		northPanel.add( artistField ); 
		//song line 
		songLabel = new JLabel( "Song Title", SwingConstants.RIGHT ); 
		northPanel.add( songLabel ); 
		songField = new JTextField(); 
		northPanel.add( songField ); 
		//album line 
		albumLabel = new JLabel( "Album Name", SwingConstants.RIGHT ); 
		northPanel.add( albumLabel ); 
		albumField = new JTextField(); 
		northPanel.add( albumField ); 
		//track line 
		trackLabel = new JLabel( "Track Length (in seconds)", SwingConstants.RIGHT ); 
		northPanel.add( trackLabel ); 
		trackField = new JTextField(); 
		northPanel.add( trackField ); 
		//buttons 
		addButton = new JButton( "Add MP3" ); 
		displayButton = new JButton( "Display MP3" );  
		findButton = new JButton( "Find MP3" ); 
		deleteButton = new JButton( "Delete MP3" ); 
		northPanel.add( addButton ); 
		northPanel.add( displayButton );
		northPanel.add( findButton );
		northPanel.add( deleteButton ); 
		
		//create text area 
		southArea = new JTextArea(); 
		
		//create new ButtonHandler for button event handling
		ButtonHandler handler = new ButtonHandler(); 
		addButton.addActionListener( handler ); 
		
		setLayout( new BorderLayout() );
		add( northPanel, BorderLayout.NORTH ); 
		add( southArea, BorderLayout.CENTER ); 
	}
	
	//private inner class for button event handling
	private class ButtonHandler implements ActionListener
	{
		//handle button event 
		public void actionPerformed( ActionEvent event )
		{	 
			//make sure all fields are filled 
			if( artistField.getText().equals( "" ) || songField.getText().equals( "" ) 
					|| albumField.getText().equals( "" ) || trackField.getText().equals( "" ) )
					southArea.setText( "Input data missing - please fill in all fields" ); 
			else {
				try 
				{	
					MP3 mp3 = new MP3( artistField.getText(), songField.getText(),
							albumField.getText(), Integer.parseInt( trackField.getText() ) ); 
				
					//display mp3 data 
					southArea.setText( mp3.toString() );
				
					//reset fields
					artistField.setText( "" ); 
					songField.setText( "" );
					albumField.setText( "" );
					trackField.setText( "" );
				}
				//integer not fed into parseInt 
				catch( NumberFormatException numberFormatMismatchException )
				{
					//string shown if exception thrown 
					southArea.setText( "must enter number for seconds" );
				}	
			}
			
		}
		
	}
	
}
