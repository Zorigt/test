//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255HJ
//MP3
//mp3 data 
//Assignment #7
//4-29-14

public class MP3 
{
	private String artist; 
	private String song;
	private String album; 
	private int trackLength; 
	
	public MP3( String artist, String song, String album, int tLength )
	{
		setArtist( artist );
		setSong( song ); 
		setAlbum( album );
		setTrackLength( tLength ); 
	}
	
	//accessors
	public String getArtist()
	{
		return artist; 
	}
	
	public String getSong()
	{
		return song; 
	}
	
	public String getAlbum()
	{
		return album;
	}
	
	public int getTrackLength()
	{
		return trackLength; 
	}
	
	//mutators
	public void setArtist( String artist )
	{
		this.artist = artist;
	}
	
	public void setSong( String song )
	{
		this.song = song; 
	}
	
	public void setAlbum( String album )
	{
		this.album = album; 
	}
	
	public void setTrackLength( int tLength )
	{
		trackLength = tLength <= 0 ? 1 : tLength;  
	}
	
	//toString converts track length into minutes and seconds 
	public String toString()
	{
		int minutes, seconds; 
		
		minutes = getTrackLength() / 60; 
		seconds = getTrackLength() - ( minutes * 60 );  
		
		return String.format( "%s | %s | %s | %d:%d", getArtist(), getSong(), 
			getAlbum(), minutes, seconds ); 			
	}
	
}
