//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255 HJ
//Date.java
//format dates into string outputs 
//Assignment #3
//3-4-14

public class Date {
	private int month; //1 - 12 
	private int day; //1 - 31 based on month
	private int year; //year greater than 0
	
	private static final int[] DAYS_IN_MONTH = //days in each month 
		{ 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }; 
	private static final int[] DAYS_IN_MONTH_LEAPYEAR = //days in each month of leap year 
		{ 0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	private static final String[] MONTH_NAMES = //month names
		{ null, "January", "February", "March", "April", "May", "June", "July", "August", 
			"September", "October", "November", "December" };

	//defualt constructor 
	public Date()
	{
		this( 1, 1, 2014 ); //set default values 
	}
	
	//constructor: call checkMonth to confirm proper value for month
	//call checkDay to confirm proper value for day and checkYear to confirm
	//year is greater than 0 
	public Date( int theMonth, int theDay, int theYear )
	{
		setMonth( theMonth ); 
		setDay( theDay );
		setYear( theYear ); 
	}
	
	public Date( String theMonth, int theDay, int theYear )
	{
		//compare strings to find month's integer value or index 
		//in DAYS_IN_MONTH
		for( int i = 1; i < MONTH_NAMES.length; i++ )
		{
			if( theMonth.equals( MONTH_NAMES[ i ] ) )
				setMonth( i ); 
		}
		setDay( theDay ); 
		setYear( theYear ); 
	}  
	
	public Date( int theDay, int theYear )
	{
		//call convert from day of year 
		//convert day of the year to month String or index value 
		setMonth( getMonthFromDayOfYear( theDay, theYear ) ); //returns month number
		setDay( getDayFromDayOfYear( theDay, theYear ) ); //returns day number of that month 
		setYear( theYear ); 
	}
	
	private int checkMonth( int testMonth )
	{
		if( testMonth > 0 && testMonth <= 12 ) //validate month
			return testMonth; 
		else
			return testMonth = 1; //invalid month has default of Jan
	}
	
	private int checkDay( int testDay )
	{
		//array variable points to correct days in month array 
		int correctYear[]; 
		
		//condition checks if leap year and assigns correctYear
		if ( isLeapYear( year) )
			correctYear = DAYS_IN_MONTH_LEAPYEAR;
		else
			correctYear = DAYS_IN_MONTH; 
		 
		if( testDay > 0 && testDay <= correctYear[ month ] )
			return testDay;
		else
			return testDay = 1; //invalid day has default of 1
	}
	
	private int checkYear( int testYear )
	{
		//condition checks year between 0 and 4 digit integer 
		if( testYear >= 0 && testYear <= 9999 )  
			return testYear;
		else
			return testYear = 2014; //invalid year has default 2014  
	}
	
	//returns month number 
	private int convertFromMonthName( String testMonth )
	{
		int monthNum = 0; 
		
		//find index of Month from month name 
		for( int i = 1; i < MONTH_NAMES.length; i++ )
		{
			if( testMonth.equals( MONTH_NAMES[ i ] ) )
				monthNum = i; 
		}
		
		return monthNum; 
	}
	 
	//returns day of the year 
	private int convertToDayOfYear( int testDay, String testMonth, int testYear )
	{
		int correctYear[];
		
		//condition checks if leap year and assigns correctYear
		if ( isLeapYear( year) )
			correctYear = DAYS_IN_MONTH_LEAPYEAR;
		else
			correctYear = DAYS_IN_MONTH; 
		
		int monthNum; 
		monthNum = convertFromMonthName( testMonth ); //returns month number
		
		int dayOfYear = 0; 
		if( monthNum > 1 ) //condition checks if month is not January 
		{	
			for( int j = 1; j < monthNum; j++ )
			{
				//add days starting from January to that month 
				dayOfYear += correctYear[ j ]; 
			}
		}
		
		dayOfYear += testDay; 
		
		return dayOfYear; 
	}
	
	//using the day of the year argument
	//returns the month 
	private int getMonthFromDayOfYear( int testDay, int testYear )
	{
		int correctYear[];
		
		if ( isLeapYear( testYear ) )
			correctYear = DAYS_IN_MONTH_LEAPYEAR;
		else
			correctYear = DAYS_IN_MONTH; 
		
		int monthNum = 1; 
		
		while( testDay > correctYear[ monthNum ] )
		{
			testDay -= correctYear[ monthNum ];
			monthNum++; 
		}
			
		return monthNum; 
	}
	
	private int getDayFromDayOfYear( int testDay, int testYear )
	{
		int correctYear[];
		
		//condition checks if leap year and assigns correctYear
		if ( isLeapYear( testYear ) )
			correctYear = DAYS_IN_MONTH_LEAPYEAR;
		else
			correctYear = DAYS_IN_MONTH; 
		
		int monthNum = 1; 
		
		while( testDay > correctYear[ monthNum ] )
		{
			//subtracts from day of year to return day of specifc month 
			testDay -= correctYear[ monthNum ];
			monthNum++; 
		}
			
		return testDay; 	
	}
	
	//returns boolean value whether leap year or not 
	private boolean isLeapYear( int testYear )
	{ 
		if( testYear % 4 == 0 )
			return true; 
		else
			return false; 
	}
	
	//accessor methods 
	//get day value
	public int getDay()
	{
		return day; 
	}
	
	//get month value
	public int getMonth()
	{
		return month; 
	}
	
	//get year value
	public int getYear()
	{
		return year; 
	}
	
	//mutator methods
	//set day value
	public void setDay( int testDay )
	{
		day = checkDay( testDay ); //validate day 
	}
	
	public void setMonth( int testMonth )
	{
		month = checkMonth( testMonth ); //validate month
	}
	
	public void setYear( int testYear )
	{
		year = checkYear( testYear ); //validate year 
	}
	
	//return String of form month/day/year
	public String toString()
	{
		return String.format( "%d/%d/%d\n", month, day, year ); 
	}
	
	//return String of form monthName day, year 
	public String toMonthDayNameDateString()
	{
		return String.format( "%s %d, %d\n", MONTH_NAMES[ month ], day, year ); 
	}
	
	//return String of form day of year and the year 
	public String toDayDateString()
	{
		return String.format( "%d %d\n", 
			convertToDayOfYear( day, MONTH_NAMES[ month ], year ), year ); 
	}	
}
