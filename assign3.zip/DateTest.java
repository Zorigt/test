//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255 HJ
//DateTest.java
//Tests Date class 
//Assignment #3
//3-4-14

import javax.swing.*; 

public class DateTest {
	public static void main( String[]args )
	{
		//instantiate date objects 
		Date date1 = new Date(); 
		Date date2 = new Date( 13, 35, 10000 );
		Date date3 = new Date( 8, 18, 2000 ); 
		Date date4 = new Date( "March", -1, -1 ); 
		Date date5 = new Date( "November", 25, 1763 );
		Date date6 = new Date( 100, 1405 ); 
		Date date7 = new Date( 11, 1880 ); 
		Date date8 = new Date( 2, 29, 2012 ); 
		
		//variables store User inputed values 
		int userMonth, userDay, userYear; 
				
		String userDate = JOptionPane.showInputDialog( "Enter date using format MM/DD/YYYY: " );
		//split user date on forward slash and input values into array
		String[] dateArray = userDate.split( "/" );
		//parse strings to integer value 
		userMonth = Integer.parseInt( dateArray[ 0 ] ); 
		userDay = Integer.parseInt( dateArray[ 1 ] ); 
		userYear = Integer.parseInt( dateArray[ 2 ] ); 

		//instantiate user object 
		Date date9 = new Date( userMonth, userDay, userYear );
		
		//format string while calling proper string methods from Date class 
		String message = String.format( "%s\n\n%s%s%s\n%s%s%s\n%s%s%s\n%s%s%s\n%s%s%s"
				+ "\n%s%s%s\n%s%s%s\n%s%s%s\n%s\n%s%s%s", "Programmed by Jonathan Co", 
				date1.toString(), date1.toMonthDayNameDateString(), date1.toDayDateString(),
				date2.toString(), date2.toMonthDayNameDateString(), date2.toDayDateString(),
				date3.toString(), date3.toMonthDayNameDateString(), date3.toDayDateString(),
				date4.toString(), date4.toMonthDayNameDateString(), date4.toDayDateString(),
				date5.toString(), date5.toMonthDayNameDateString(), date5.toDayDateString(),
				date6.toString(), date6.toMonthDayNameDateString(), date6.toDayDateString(),
				date7.toString(), date7.toMonthDayNameDateString(), date7.toDayDateString(),
				date8.toString(), date8.toMonthDayNameDateString(), date8.toDayDateString(),
				"User Inputed Date:",
				date9.toString(), date9.toMonthDayNameDateString(), date9.toDayDateString() ); 
		
		JOptionPane.showMessageDialog( null, message );
	}
	
}
