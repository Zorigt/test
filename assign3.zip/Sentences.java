//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255 HJ
//Sentences.java
//random-number generation to create sentences
//Assignment #3
//3-4-14

import java.util.*;  
import javax.swing.*; 

public class Sentences 
{
	public static void main( String[]args )
	{
		//four arrays of strings 
		String[] article = { "the", "a", "one", "some", "any" }; 
		String[] noun = { "boy", "girl", "dog", "town", "car", "cat", "city" }; 
		String[] verb = { "drove", "jumped", "ran", "walked", "skipped", "stopped", "sped" }; 
		String[] preposition = { "to", "from", "over", "under", "on" }; 
		
		//create objects of Random and StringBuilder
		Random random = new Random(); 
		StringBuilder buffer = new StringBuilder(); 
		
		//variable to be assigned with new line character
		int index = 0;  
		
		//loop 20 times 
		for( int i = 0; i < 20; i++ )
		{	
			//create sentence by selecting words at random from String arrays 
			buffer.append( article[ random.nextInt( 5 ) ] ).append( " " ).append( 
			noun[ random.nextInt( 7 ) ] ).append( " " ).append( verb [ random.nextInt( 7 ) ] )
			.append( " " ).append( preposition[ random.nextInt( 5 ) ] ).append( " " )
			.append( article[ random.nextInt( 5 ) ] ).append( " " ).append( 
			noun[ random.nextInt( 7 ) ] ).append( "." ).append( "\n" );
		
			//condition capitalizing first character of first sentence and then   
			//adding one to index to capitalize first character of next sentence 
			if( i == 0 )
			{
				buffer.setCharAt( 0, Character.toUpperCase( buffer.charAt( 0 ) ) );
				index = buffer.toString().indexOf( '\n' ); 
			} else {
				buffer.setCharAt( index + 1, Character.toUpperCase( buffer.charAt( index + 1 ) ) );
				index = buffer.toString().indexOf( '\n', index + 1 );
			} 
		
		}
		
		//create object of JTextArea class and specify text area size 
		JTextArea outputTextArea = new JTextArea( 10, 20 ); 
		//set text of JTextArea to String built by StringBuilder 
		outputTextArea.setText( "Programmed by Jonathan Co\n\n");
		outputTextArea.append( buffer.toString() );
		///output text area using dialog box 
		JOptionPane.showMessageDialog( null, outputTextArea );
	}
	
}
