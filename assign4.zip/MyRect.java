//Jonathan Co
//jco@my.smccd.edu
//CIS 255HJ
//MyRect.java
//draw unfilled or filled rectangles 
//Assignment #4
//3-11-14

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class MyRect
{
   private int x1; // x-coordinate of first endpoint
   private int y1; // y-coordinate of first endpoint
   private int x2; // x-coordinate of second endpoint
   private int y2; // y-coordinate of second endpoint
   private Color myColor; // color of this shape
   private boolean filled; //shape filled or not 
 
   //no argument constructor 
   public MyRect()
   {
	   //assign defaults 
	   this( 0, 0, 0, 0, Color.BLACK, false );  
   }
   
   // constructor with input values
   public MyRect( int x1, int y1, int x2, int y2, Color color, boolean fill )
   {
      setX1( x1 ); // set x-coordinate of first endpoint
      setY1( y1 ); // set y-coordinate of first endpoint
      setX2( x2 ); // set x-coordinate of second endpoint
      setY2( y2 ); // set y-coordinate of second endpoint
      setMyColor( color ); //set the color
      setFilled( fill ); //set fill argument 
   } // end MyLine constructor
   
   //accessors 
    public int getX1()
    {
    	return x1; 
    }
    
    public int getY1()
    {
    	return y1; 
    }
   
    public int getX2()
    {
    	return x2; 
    }
    
    public int getY2()
    {
    	return y2; 
    }
    
    public Color getColor()
    {
    	return myColor; 
    }
    
    public boolean getFilled()
    {
    	return filled; 
    }
    
    //mutators
    public void setX1( int x1 )
    {
    	if( x1 >= 0 )
    		this.x1 = x1; 
    	else
    		this.x1 = 0; 
    }
    
    public void setY1( int y1 )
    {
    	if( y1 >= 0 )
    		this.y1 = y1; 
    	else 
    		this.y1 = 0; 
    }
    
    public void setX2( int x2 )
    {
    	if( x2 >= 0 )
    		this.x2 = x2; 
    	else
    		this.x2 = 0;
    }
    
    public void setY2( int y2 )
    {
    	if( y2 >= 0 )
    		this.y2 = y2; 
    	else 
    		this.y2 = 0; 
    }
    
    public void setMyColor( Color color )
    {
    	myColor = color; 
    }
    
    public void setFilled( boolean fill )
    {
    	filled = isFilled(); 
    }
    
    //get upper left x coordinate
    public int getUpperLeftX()
    {
    	return Math.min( getX1(), getX2() ); 
    }
    
    //get upper left y coordinate 
    public int getUpperLeftY()
    {
    	return Math.min( getY1(), getY2() ); 
    }
    
    //width of Oval 
    public int getWidth()
    {
    	return Math.abs( getX1() - getX2() ); 
    }
    
    //height of Oval
    public int getHeight()
    {
    	return Math.abs( getY1() - getY2() ); 
    }
    
    //predicate method 
    public boolean isFilled()
    {
    	//create random object 
    	Random random = new Random();
    	//random generation of true or false 
    	return random.nextBoolean();
    }
    
   // Actually draws the line
   public void draw( Graphics g )
   {
      g.setColor( getColor() );

      //condition if filled is true 
      if( getFilled() )
    	  g.fillRect( getUpperLeftX(), getUpperLeftY(), getWidth(), getHeight() );
      else
          g.fillRect( getUpperLeftX(), getUpperLeftY(), getWidth(), getHeight() );
   } // end method draw
   
} // end class MyLine