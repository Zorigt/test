//Jonathan Co
//jco@my.smccd.edu
//CIS 255HJ
//DrawPanel.java
//uses classes MyLine, MyOval and MyRect to draw shapes 
//Assignment #4
//3-11-14


// Fig. 8.19: DrawPanel.java *with adjustments* 
// Program that uses class MyLine
// to draw random lines.
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.JPanel;

public class DrawPanel extends JPanel
{
   private Random randomNumbers = new Random();   
   private static MyLine[] lines; // array of lines
   private static MyOval[] ovals; //array of ovals
   private static MyRect[] rectangles; //array of rectangles 

   // constructor, creates a panel with random shapes
   public DrawPanel()
   {
      setBackground( Color.WHITE );
      
      //create arrays with random lengths 1 - 5 
      lines = new MyLine[ 1 + randomNumbers.nextInt( 5 ) ]; 
      ovals = new MyOval[ 1 + randomNumbers.nextInt( 5 ) ];
      rectangles = new MyRect[ 1 + randomNumbers.nextInt( 5 ) ]; 
      
      //filled argument for oval and rectangle constructor parameter
      boolean fill = randomNumbers.nextBoolean(); 

      // create lines
      for ( int count = 0; count < lines.length; count++ )
      {
         // generate random coordinates
         int x1 = randomNumbers.nextInt( 590 );
         int y1 = randomNumbers.nextInt( 590 );
         int x2 = randomNumbers.nextInt( 590 );
         int y2 = randomNumbers.nextInt( 590 );
         
         // generate a random color
         Color color = new Color( randomNumbers.nextInt( 256 ), 
            randomNumbers.nextInt( 256 ), randomNumbers.nextInt( 256 ) );
         
         // add the line to the list of lines to be displayed
         lines[ count ] = new MyLine( x1, y1, x2, y2, color );
      }
      
      // create ovals
      for ( int i = 0; i < ovals.length; i++ )
      {
         // generate random coordinates
         int x1 = randomNumbers.nextInt( 590 );
         int y1 = randomNumbers.nextInt( 590 );
         int x2 = randomNumbers.nextInt( 590 );
         int y2 = randomNumbers.nextInt( 590 );
         
         // generate a random color
         Color color = new Color( randomNumbers.nextInt( 256 ), 
            randomNumbers.nextInt( 256 ), randomNumbers.nextInt( 256 ) );
                 
         //add oval to the list of ovals to be displayed
         ovals[ i ] = new MyOval( x1, y1, x2, y2, color, fill ); 
      } // end for 
      
   // create rectangles 
      for ( int i = 0; i < rectangles.length; i++ )
      {
         // generate random coordinates
         int x1 = randomNumbers.nextInt( 590 );
         int y1 = randomNumbers.nextInt( 590 );
         int x2 = randomNumbers.nextInt( 590 );
         int y2 = randomNumbers.nextInt( 590 );
         
         // generate a random color
         Color color = new Color( randomNumbers.nextInt( 256 ), 
            randomNumbers.nextInt( 256 ), randomNumbers.nextInt( 256 ) );
         
         //add oval to the list of ovals to be displayed
         rectangles[ i ] = new MyRect( x1, y1, x2, y2, color, fill ); 
      } // end for 
   } // end DrawPanel constructor 

   // for each shape array, draw the individual shapes
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g );

      // draw the lines
      for ( MyLine line : lines )
         line.draw( g );
      
      //draw the ovals
      for( MyOval oval : ovals )
    	  oval.draw( g ); 
      
      //draw the rectangles 
      for( MyRect rectangle : rectangles )
    	  rectangle.draw( g );
      
   } // end method paintComponent
   
   //method that returns a String containing status text 
   public static String getStatusText()
   {
	   //format output 
	   String message = String.format( "%s %d  %s %d  %s %d",
			   "Lines:", lines.length, 
			   "Ovals:", ovals.length,
			   "Rectangles:", rectangles.length ); 
	   
	   return message;
   }
   
} // end class DrawPanel