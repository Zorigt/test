//Jonathan Co
//jco@my.smccd.edu
//CIS 255HJ
//TestDraw.java
//tests class DrawPanel
//Assignment #4
//3-11-14


// Fig. 8.20: TestDraw.java
// Creating a JFrame to display a DrawPanel.
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;  

public class TestDraw
{
   public static void main( String[] args )
   {
      DrawPanel panel = new DrawPanel();
      JFrame application = new JFrame( "Programmed by Jonathan Co" );
      //create object of class JLabel 
      JLabel southLabel = new JLabel(); 
   
      application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      
      //set the label to display text from DrawPanel 
      //getStatusText method 
      southLabel.setText( DrawPanel.getStatusText() ); 
      //add label to frame 
      application.add( southLabel, BorderLayout.SOUTH ); 
      application.add( panel );
      application.setSize( 600, 600 );
      application.setVisible( true );
   } // end main
} // end class TestDraw