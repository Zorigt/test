//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255HJ
//MyOval.java  
//MyOval class represents a oval
//3-25-14

import java.awt.*;

public class MyOval extends MyBoundedShape
{
   //no argument constructor 
   public MyOval()
   {
	   //assign defaults 
	   this( 0, 0, 0, 0, Color.BLACK, false );  
   }
   
   // constructor with input values
   public MyOval( int x1, int y1, int x2, int y2, Color color, boolean fill )
   {
      setX1( x1 ); // set x-coordinate of first endpoint
      setY1( y1 ); // set y-coordinate of first endpoint
      setX2( x2 ); // set x-coordinate of second endpoint
      setY2( y2 ); // set y-coordinate of second endpoint
      setMyColor( color ); //set the color
      setFilled( fill ); //set fill argument 
   } 
    
   // Actually draws the line
   //override abstract method draw inherited from MyShape
   @Override 
   public void draw( Graphics g )
   {
      g.setColor( getColor() );

      //condition if filled is true 
      if( isFilled() )
    	  g.fillOval( getUpperLeftX(), getUpperLeftY(), getWidth(), getHeight() );
      else
          g.drawOval( getUpperLeftX(), getUpperLeftY(), getWidth(), getHeight() );
   } // end method draw
   
} // end class MyLine