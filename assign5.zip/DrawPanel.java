//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255HJ
//DrawPanel.java  
//fill MyShape array with 3 randomly selected shapes
//3-25-14

import java.awt.*; 
import java.util.Random;

import javax.swing.JPanel;

public class DrawPanel extends JPanel
{
   private Random randomNumbers = new Random(); 
   //array of type MyShape size 20 
   private MyShape[] shapes = new MyShape[ 20 ];  
   //declare counts of shapes 
   private static int lineCount, ovalCount, rectCount; 
   
   // constructor, creates a panel with random shapes
   public DrawPanel()
   {
      setBackground( Color.WHITE );
      
      for( int i = 0; i < shapes.length; i++ )
      {
    	// generate random coordinates
          int x1 = randomNumbers.nextInt( 999 );
          int y1 = randomNumbers.nextInt( 999 );
          int x2 = randomNumbers.nextInt( 999 );
          int y2 = randomNumbers.nextInt( 999 );
          
          // generate a random color
          Color color = new Color( randomNumbers.nextInt( 256 ), 
             randomNumbers.nextInt( 256 ), randomNumbers.nextInt( 256 ) );
          
          //generate filled parameter
          boolean fill = randomNumbers.nextBoolean();
          
          //generate random number to draw shape  
          int shapeNumber = randomNumbers.nextInt( 3 ); 
          
          //fill array with shapes 
          switch( shapeNumber )
          {
          	case 0: 
          		shapes[ i ] = new MyLine( x1, y1, x2, y2, color ); 
          		lineCount++; //count lines
          	break; 
          	case 1: 
          		shapes[ i ] = new MyOval( x1, y1, x2, y2, color, fill ); 
          		ovalCount++; //count ovals 
          	break; 
          	default:
          		shapes[ i ] = new MyRectangle( x1, y1, x2, y2, color, fill );
          		rectCount++; //count rectangles 
          	break;         
          }
         
      } //end for 
           
   } 

   //draw the individual shapes
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g );

      //generically process each element and draw shape 
      for( MyShape shape : shapes )  
    	  shape.draw( g ); 
      
   } // end method paintComponent
   
   //method that returns a String containing status text 
   public static String getStatusText()
   {
	   //format output 
	   String message = String.format( "%s %d  %s %d  %s %d",
			   "Lines:", lineCount, 
			   "Ovals:", ovalCount,
			   "Rectangles:", rectCount ); 
	   
	   return message;
   }	
   
} // end class DrawPanel