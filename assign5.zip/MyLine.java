//Jonathan Co 
//jco5@my.smccd.edu
//CIS 255HJ
//MyLine.java  
//MyLine class represents a line.
//3-25-14

import java.awt.*; 

public class MyLine extends MyShape
{
   //no argument constructor 
   public MyLine()
   {
	   this( 0, 0, 0, 0, Color.BLACK ); //default is black 
   }
   
   // constructor with input values
   public MyLine( int x1, int y1, int x2, int y2, Color color )
   {
      setX1( x1 ); // set x-coordinate of first endpoint
      setY1( y1 ); // set y-coordinate of first endpoint
      setX2( x2 ); // set x-coordinate of second endpoint
      setY2( y2 ); // set y-coordinate of second endpoint
      setMyColor( color ); // set the color
   } 
    
   // Actually draws the line; override abstract method draw in MyShapes
   @Override 
   public void draw( Graphics g )
   {
      g.setColor( getColor() );
      g.drawLine( getX1(), getY1(), getX2(), getY2() );
   } // end method draw
   
} // end class MyLine